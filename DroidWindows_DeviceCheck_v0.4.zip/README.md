# DroidWindows Universal — Starter 0.3

## Objetivo
Base de aplicación Android pensada para Samsung Galaxy J2 Prime, Android 6.0.1.

## Ajustes
- minSdk 23: Android 6.0 o posterior; permite instalar en J2 Prime y versiones posteriores de Android compatibles.\n- ABI declaradas: `armeabi-v7a` y `arm64-v8a`.
- targetSdk 28 para una base sencilla y compatible con dispositivos antiguos.
- Interfaz nativa ligera, sin Compose ni bibliotecas de UI pesadas.
- Selector Android de documentos para localizar un EXE/MSI.

## Estado real
Esta app NO ejecuta todavía programas de Windows. La selección de un archivo no es emulación. Falta integrar y compilar el motor de compatibilidad, su runtime y las bibliotecas nativas adecuadas.

## Importante sobre el J2 Prime
Las variantes J2 Prime suelen tener RAM muy limitada y una plataforma ARM de 32 bits en su firmware. Antes de decidir Box86/Box64 hay que confirmar la arquitectura ABI del sistema (`armeabi-v7a` o `arm64-v8a`) en el dispositivo. Box64 requiere entorno ARM64; si el sistema es ARM de 32 bits, no puede usarse Box64 como backend directo. Incluso con Box86, Wine y gráficos, el soporte y rendimiento serán limitados.

## Compilar
1. Abrir en Android Studio reciente con JDK 17.
2. Sincronizar Gradle.
3. Ejecutar en dispositivo Android API 23+.

`compileSdk 35` es la API usada para compilar; no exige que el teléfono tenga Android 15. El `minSdk 23` es el requisito de instalación.

## Próximo paso
Identificar ABI y GPU del teléfono; después evaluar un backend ARM32 viable y sus licencias antes de integrarlo.

## Compatibilidad universal
La aplicación base no restringe la instalación a un modelo concreto. Incluye ARM de 32 y 64 bits en el empaquetado. El motor de Windows deberá aportar bibliotecas nativas adecuadas para cada ABI; hasta entonces, compatibilidad de instalación no equivale a ejecución de EXE.

## Starter 0.4 — diagnóstico
La pantalla consulta `Build.SUPPORTED_ABIS`, versión Android, modelo y memoria total para mostrar datos del dispositivo. Es una comprobación inicial; no determina por sí sola el soporte gráfico ni garantiza que un motor x86 Windows funcione.
