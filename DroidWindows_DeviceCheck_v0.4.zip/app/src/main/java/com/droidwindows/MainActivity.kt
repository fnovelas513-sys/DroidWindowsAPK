package com.droidwindows

import android.app.Activity
import android.app.ActivityManager
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var deviceInfo: TextView
    private val selectFileRequest = 7

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            setBackgroundColor(Color.rgb(16, 27, 45))
        }

        page.addView(label("DroidWindows", 28f, Color.WHITE))
        page.addView(label("Universal • Diagnóstico del dispositivo", 14f, Color.LTGRAY).apply {
            setPadding(0, dp(5), 0, dp(18))
        })

        val detect = Button(this).apply {
            text = "Detectar compatibilidad"
            setOnClickListener { refreshDeviceInfo() }
        }
        page.addView(detect)

        val choose = Button(this).apply {
            text = "Seleccionar instalador EXE"
            setOnClickListener { openFilePicker() }
        }
        page.addView(choose)

        deviceInfo = label("", 13f, Color.WHITE).apply {
            setPadding(0, dp(16), 0, dp(12))
        }
        page.addView(deviceInfo)

        status = label("Motor Windows: aún no integrado", 13f, Color.rgb(255, 210, 130))
        page.addView(status)

        page.addView(label(
            "Esta versión identifica el hardware y permite elegir un archivo. No ejecuta EXE todavía: falta el backend Wine/Box86/Box64.",
            12f, Color.LTGRAY
        ).apply { setPadding(0, dp(12), 0, 0) })

        setContentView(page)
        refreshDeviceInfo()
    }

    private fun refreshDeviceInfo() {
        val abis = Build.SUPPORTED_ABIS.joinToString(", ")
        val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val memory = ActivityManager.MemoryInfo()
        manager.getMemoryInfo(memory)
        val totalRamMb = memory.totalMem / (1024 * 1024)
        val archNote = when {
            Build.SUPPORTED_ABIS.any { it == "arm64-v8a" } ->
                "ABI ARM64 disponible (también puede soportar ARM32)."
            Build.SUPPORTED_ABIS.any { it == "armeabi-v7a" } ->
                "Sistema ARM32: requiere backend de 32 bits."
            else -> "ABI no reconocida: revisar compatibilidad del motor."
        }
        deviceInfo.text = "Modelo: ${Build.MANUFACTURER} ${Build.MODEL}\n" +
            "Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\n" +
            "ABI: $abis\nRAM total reportada: ${totalRamMb} MB\n$archNote"
    }

    private fun openFilePicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, selectFileRequest)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == selectFileRequest && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                status.text = "Archivo elegido: ${uri.lastPathSegment ?: uri}\nPendiente: instalar/ejecutar con el motor."
                Toast.makeText(this, "Archivo seleccionado; EXE aún no ejecutable.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun label(value: String, size: Float, color: Int) = TextView(this).apply {
        text = value
        textSize = size
        setTextColor(color)
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density + 0.5f).toInt()
}
