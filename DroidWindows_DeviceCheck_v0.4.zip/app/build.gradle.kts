plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.droidwindows"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.droidwindows"
        minSdk = 23
        targetSdk = 28
        versionCode = 3
        versionName = "0.3.0-universal"
    }
}
